#import <UIKit/UIKit.h>

#import <GoogleMaps/GoogleMaps.h>

@interface PolylinesViewController : UIViewController  <GMSMapViewDelegate>

@end
