#import <UIKit/UIKit.h>

@interface DoubleMapViewController : UIViewController

@end
